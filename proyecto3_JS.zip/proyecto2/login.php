<?php
include("base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include("base/funciones.php"); // Incluye el archivo de funciones

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $correo = $_POST['correo'];
    $pass = $_POST['contra'];
    //se verifica si los datos son validos
    // Esta feo y es peor que lo anterior, pero es para que se adapte a JavaScript
    if($correo != "" && $pass != "" && strlen($correo) <= 100 && strlen($pass) <= 100){
            if(!isset($_SESSION))
                session_start(); // Inicia la sesión si no está iniciada
            // Obtiene los datos del formulario
            
            // Verifica si el usuario y la contraseña son correctos
            $query = "SELECT * FROM usuario WHERE correo='$correo' AND contraseña='$pass' limit 1";
            $result = mysqli_query($con, $query);
            // Verifica si la consulta se realizó correctamente y si el usuario existe
            if($result && mysqli_num_rows($result) > 0) {
                $user_data = mysqli_fetch_assoc($result); // Obtiene los datos del usuario
                $_SESSION['idUsuario'] = $user_data['idUsuario']; // Guarda el nombre de usuario en la sesión
                $_SESSION['tipoUsuario'] = $user_data['tipoUsuario']; // Guarda el tipo de usuario en la sesión
                if($user_data['tipoUsuario'] == 1) {
                    //si es admin, redirige a la página de inicioAdmin.php
                    header("Location: admin/inicioAdmin.php");
                } else {
                    //si es usuario normal, redirige a la página de inicio.php
                    header("Location: inicio.php"); 
                } 
            }else {
                // Si el usuario no existe, muestra un mensaje de error
                echo "<script>alert('Usuario o contraseña incorrectas');</script>";
            }
        }
    
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=devic  e-width, initial-scale=1.0">
    <title>Inicio de sesion</title>
    <?php include ('base/links.php'); ?>
</head>
<body>
<header>
    <?php include 'base/header.php'; ?>
</header>    
    <?php include 'base/barra.php'; ?>
    <br>
    <h2> Inicio de sesión </h2>
    <section class="formCorreo">
    <form method="POST" class="formCorreo formulario" name="form1">
        <fieldset>
            <div class="div-registro">
                <div class="camposRegistro">
                    <label>Correo</label>
                    <input class="input-text" type="email" placeholder="Correo electrónico" id="correo" name="correo" for="correo">
                </div>
       
                <div class="camposRegistro">
                    <label>Contraseña</label>
                    <input class="input-text" type="password" placeholder="Tu Contraseña" id="contra" name="contra" for="contra">
                </div>
                <div class="campos-registro flex">
                    <input class="boton w-sm-100" type="submit" value="Login">
                </div>
            </div>
            <div class="alinear-derecha flex">
                <p>¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a></p>
            </div>
        </fieldset>
    </form>
    
</section>
<?php include 'base/footer.php'; ?>
<script src="base/scriptlogin.js"></script>
</body>
</html>
