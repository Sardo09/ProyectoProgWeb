<?php
include ("base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include ("base/funciones.php"); // Incluye el archivo de funciones

$query = "SELECT * FROM aviones ORDER BY idAvion DESC"; 
$result = mysqli_query($con, $query);  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo</title>
    <?php include ('base/links.php'); ?>
</head>
<body>
  <header>
    <?php include 'base/header.php'; ?>
  </header>    
  <?php include 'base/barra.php'; ?>
  <br>
      <h2>Vuelos Disponibles</h2>
      
      <section class="flight-list">
        <?php
          if ($result && mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)) {
            $lugarViaje = $row['lugarViaje'];
            $descLugar = $row['descLugar'];
            $precio = $row['precio'];
            $numAsientos = $row['numAsientos'];
            $imagen = $row['imagen'];
            $fechaSalida = $row['fechaSalida'];
            $fechaRegreso = $row['fechaRegreso'];
            
            echo '<div class="flight-card" style="width-fit-content: 100%; height: 100%;">
            <h3>'.$lugarViaje.'</h3>';
            if ($imagen != "") {
                echo '<img src="imagenes/'.$imagen.'" class="img-promo">';
                echo '<hr>';
            }    
            echo '
            <p><strong>'.$descLugar.'</strong></p>';?>
            <!--script para mostrar la fecha de salida-->
            <p><strong>Fecha de salida:</strong>
            <div id="divSalida" class="divSalida"></div>
            <script>
                var options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
                var fechaSalida = new Date("<?php echo $fechaSalida ?>");  

                const fechaMostrar = document.createElement('p');
                const divMostrar = document.querySelector('.divSalida');

                fechaMostrar.textContent = fechaSalida.toLocaleDateString("es-US", options);
                divMostrar.appendChild(fechaMostrar);
            </script>
            </p>
            <p><strong>Fecha de regreso:</strong>
            <div id="divRegreso" class="divRegreso"></div>
            <!--script para mostrar la fecha de regreso-->
            <script>
                var options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
                var fechaRegreso = new Date("<?php echo $fechaRegreso ?>");  

                const fechaMostrar2 = document.createElement('p');
                const divMostrar2 = document.querySelector('.divRegreso');

                fechaMostrar2.textContent = fechaRegreso.toLocaleDateString("es-US", options);
                divMostrar2.appendChild(fechaMostrar2);x`
            </script>
            </p>  
            <?php if ($numAsientos>0)//se asegura que se tengan asientos disponibles
              echo '<p><strong>Asientos disponibles:</strong>'.$numAsientos.'</p>
              <p><strong>Precio:</strong>$'.$precio.'MXN</p> 
              <a class="book-button" type="submit" href="src/pagCompra.php?id='.$row['idAvion'].'">Reservar Ahora</a>';
            else
              echo '<p><strong>ASIENTOS AGOTADOS</p>';
            echo'</div>';
            }
        }
        ?>
      </section>
      <?php include 'base/footer.php'; ?>
</body>
</html>