<?php
include ("../base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include ("../base/funciones.php"); // Incluye el archivo de funciones
require_once '..\composer\vendor\autoload.php';

//se agarran los valores del boleto
$query = "SELECT * FROM aviones WHERE idAvion=".$_REQUEST['id'];
$result = mysqli_query($con, $query);
if($result && mysqli_num_rows($result) > 0){
    $row = mysqli_fetch_assoc($result);
    $id = $row['idAvion'];
    $lugarViaje = $row['lugarViaje'];
    $descLugar = $row['descLugar'];
    $precio = $row['precio'];
    $numAsientos = $row['numAsientos'];
    $imagen = $row['imagen'];
    $fechaSalida = $row['fechaSalida'];
    $fechaRegreso = $row['fechaRegreso'];
}

//Se reduce en 1 la cantidad de asientos
$query = "UPDATE aviones SET numAsientos=".($numAsientos-1)." WHERE idAvion=".$_REQUEST['id'];
$result = mysqli_query($con, $query);

// reference the Dompdf namespace
use Dompdf\Dompdf;

// instantiate and use the dompdf class
$dompdf = new Dompdf();
$dompdf->loadHtml('
<table class="log">
    <tr>
        <td style="width: 10%;"><h1 class="logo">AeroSeguro</h1></td>
    </tr>
    <tr><td><h1>RECIBO</h1></td></tr>
    <tr><td><h2>Boleto a: '.$lugarViaje.'</td></tr>
    <tr><td>Se pagó: $'.$precio.'MXN</td></tr>
    <tr><td>Fecha de salida: '.$fechaSalida.'</td></tr>
    <tr><td>Fecha de regreso: '.$fechaRegreso.'</td></tr>
    <tr><td>Feliz viaje!</td></tr></h2>
</table>');


// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
$dompdf->stream();
header('Location: ../catalogo.php');
echo "<script>alerta(Pago exitoso, ¡Gracias por usar AeroSeguro!)</script>";


?>