<?php //ESTO FUE HECHO CON STRIPE.COM
// Este archivo se encarga de crear la sesión de pago con Stripe y redirigir al usuario a la página de pago
// pero no se usa porque Paypal tiene funcion de tarjeta
include ("../base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include ("../base/funciones.php"); // Incluye el archivo de funciones
require_once '..\composer\vendor\autoload.php';

//se agarran los valores del boleto
$query = "SELECT * FROM aviones WHERE idAvion=".$_REQUEST['id'];
$result = mysqli_query($con, $query);
if($result && mysqli_num_rows($result) > 0){
    $row = mysqli_fetch_assoc($result);
    $id = $row['idAvion'];
    $lugarViaje = $row['lugarViaje'];
    $descLugar = $row['descLugar'];
    $precio = $row['precio'];
    $numAsientos = $row['numAsientos'];
    $imagen = $row['imagen'];
    $fechaSalida = $row['fechaSalida'];
    $fechaRegreso = $row['fechaRegreso'];
}

$stripe = new \Stripe\StripeClient('sk_test_51RNNBCR7nkDaaxiHIFxicqLQSlXV00AmEQbIbSJetfCdt4fZP6sVdcqQFVnXmi7eg2pwCNivV7N0unl2XDgNw0Hn00LoonSA93');

$checkout_session = $stripe->checkout->sessions->create([
  'line_items' => [[
    'price_data' => [
      'currency' => 'mxn',
      'product_data' => [
        'name' => 'Boleto a'.$lugarViaje, //nombre del boleto
      ],
      'unit_amount' => $precio*100, //valor de la venta
    ],
    'quantity' => 1,
  ]],
  'mode' => 'payment',
  'success_url' => 'http://localhost/proyecto2/src/recibo.php?id='.$id.'',
  'cancel_url' => 'http://localhost/proyecto2/catalogo.php?id='.$id.'',
]);

header("HTTP/1.1 303 See Other");
header("Location: " . $checkout_session->url);
?>
