<?php
include ("../base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include ("../base/funciones.php"); // Incluye el archivo de funciones
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compra de boleto</title>
    <!--styles.css-->
    <link rel="preload" href="..\css\styles.css" as="style">
    <link href="..\css\styles.css" rel="stylesheet">
    <!--Script para bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <!--Logo-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=connecting_airports" />
</head>
<body>
    <header>
        <?php include '../base/header.php'; ?>
    </header>    
    <?php include '../base/barra.php'; ?>
    <br>
    <main class="contenedor sombra">
        <!-- menu para verificar la compra del viaje dependiendo de lo seleccionado en catalogo.php -->
        <?php 
        $query = "SELECT * FROM aviones WHERE idAvion=".$_REQUEST['id'];
        $result = mysqli_query($con, $query);
        if($result && mysqli_num_rows($result) > 0){
            $row = mysqli_fetch_assoc($result);
            $id = $row['idAvion'];
            $lugarViaje = $row['lugarViaje'];
            $descLugar = $row['descLugar'];
            $precio = $row['precio'];
            $numAsientos = $row['numAsientos'];
            $imagen = $row['imagen'];
            $fechaSalida = $row['fechaSalida'];
            $fechaRegreso = $row['fechaRegreso'];
        }
        ?>
        <section class="formCorreo">
            <form class="formCorreo" enctype="multipart/form-data">
                <fieldset>
                    <?php 
                    echo '<h1 style="text-align: center">'.$lugarViaje.'</h1>';
                    echo '<hr>';
                    if ($imagen != "") {
                        echo '<img src="../imagenes/'.$imagen.'" class="img-promo">';
                        echo '<hr>';
                    }
                    ?>
                    <h2><?php echo $descLugar ?><br>
                    Fecha de salida: <div id="divSalida" class="divSalida"></div>
                    <!--script para mostrar la fecha de salida-->
                    <script>
                        var options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
                        var fechaSalida = new Date("<?php echo $fechaSalida ?>");  

                        const fechaMostrar = document.createElement('h2');
                        const divMostrar = document.querySelector('.divSalida');

                        fechaMostrar.textContent = fechaSalida.toLocaleDateString("es-US", options);
                        divMostrar.appendChild(fechaMostrar);
                    </script>
                    Fecha de regreso:<div id="divRegreso" class="divRegreso"></div>
                    <!--script para mostrar la fecha de regreso-->
                    <script>
                        var options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
                        var fechaRegreso = new Date("<?php echo $fechaRegreso ?>");  

                        const fechaMostrar2 = document.createElement('h2');
                        const divMostrar2 = document.querySelector('.divRegreso');

                        fechaMostrar2.textContent = fechaRegreso.toLocaleDateString("es-US", options);
                        divMostrar2.appendChild(fechaMostrar2);
                    </script>
                    Precio: <span>$<?php echo $precio ?> MXN</span></h2>
                    

                   
                </fieldset>
            </form>
            <?php 
            //Boton para pago con tarjeta, sin usar porque paypal es mejor
//             echo '<table><tr><td style="width: 50%;"><form action="create-checkout-session.php?id='.$id.'" method="POST">
//                 <button type="submit" class="search-button" 
//                 style="background-color:rgb(255, 255, 255); 
//                 color:rgb(0, 0, 0); width: 100%;"><i class="fa-brands fa-cc-visa"> <i class="fa-brands fa-cc-mastercard"></i></i>Tarjetas</button>
//             </form>
//             </td>';
//             ?>
            <td>
            <div class="paypal-wrapper">
                <div id="paypal-button-container" class="paypal-container"></div>
            </div>
            
            <!--Boton para pago con Paypal-->
            </td></tr>
            </table>
        </section>
    </main>

    <script src="https://www.paypal.com/sdk/js?client-id=Ab8Z7sjatvbhqI1-GTMX_myogcP-3sQkLAITDLv8WBgzEui5F_7li4zxp2aJH1hbkQb5b9omynYxKjTZ"></script>
    <script>
        paypal.Buttons({
            createOrder: function(data, actions) {
                // Crear la orden con el monto total a pagar
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: '<?= htmlspecialchars($precio/20) ?>' // Precio calculado dinámicamente en dolares
                        }
                    }]
                });
            },
            onApprove: function(data, actions) {
                // Capturar el pago cuando se aprueba
                return actions.order.capture().then(function(details) {
                    window.location.href = "recibo.php?id=<?php echo $id; ?>"; // Redirigir a la página de confirmación
                });
            }
        }).render('#paypal-button-container'); // Renderizar el botón de PayPal
    </script>
    <?php include '../base/footer.php'; ?>
</body>
</html>