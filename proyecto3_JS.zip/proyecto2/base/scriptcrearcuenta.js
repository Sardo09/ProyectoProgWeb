
//script para revisar el formulario de registro
const datos = { //objeto global para almacenar los datos del formulario
    nombre: '',
    tel: '',
    correo: '',
    contra: ''
}

//variables de verificación de datos
var ercorreo=/^[^@\s]+@[^@\.\s]+(\.[^@\.\s]+)+$/;
var ernumero=/^[0-9]+$/;
//constantes
const nombre = document.querySelector('#nombre');
const tel = document.querySelector('#tel');
const correo = document.querySelector('#correo');
const contra = document.querySelector('#contra');
const formulario = document.querySelector('.formulario');

//Evento del submit
formulario.addEventListener('submit', function(evento){ //submit se ejecuta cuando se envia el formulario
    evento.preventDefault();
    //validar formulario
    const{ nombre, tel, correo, contra } = datos;
    if(nombre === '' || tel === '' || correo === '' || contra === ''){
        mostrarAlerta('Todos los campos son obligatorios', true);
        return; //corta el codigo
    }else if (formulario.nombre.value.length > 100){
        mostrarAlerta('Nombre invalido, es muy grande', true);
        return;
    }else if (formulario.tel.value.length > 16){
        mostrarAlerta('Teléfono invalido, es muy grande', true);
        return;
    }else if (!ernumero.test(formulario.tel.value)){
        mostrarAlerta('Teléfono invalido, no son números', true);
        return;
    }else if(formulario.correo.value.length > 100){
        mostrarAlerta('Correo invalido, es muy grande', true);
        return;
    }else if(!ercorreo.test(formulario.correo.value)){
        mostrarAlerta('Correo invalido, no cuenta con correo verificable', true);
        return;
    }else if(formulario.contra.value.length>100){
        mostrarAlerta('Correo invalido, es muy grande', true);
        return;
    }

    //enviar el formulario
    mostrarAlerta('Cuenta creada correctamente');
    formulario.submit();
});

nombre.addEventListener('input', leerTexto);
tel.addEventListener('input', leerTexto);
correo.addEventListener('input', leerTexto);
contra.addEventListener('input', leerTexto);

function leerTexto(e){
    // console.log(e.target.value);

    datos[e.target.id] = e.target.value; //almacena el valor del input en el objeto datos
    // console.log(datos); 
}

function mostrarAlerta(msg, error = null){
    const alerta = document.createElement('P');
    alerta.textContent = msg;

    if(error){
        alerta.classList.add('error');
    }else{
        alerta.classList.add('correcto');
    }

    formulario.appendChild(alerta); //agrega el elemento p al formulario
    
    //desaparesca despues de 5 segundos
    setTimeout(()=>{
        alerta.remove(); //elimina el elemento p
    }, 5000); 
}