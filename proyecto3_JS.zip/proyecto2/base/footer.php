<footer class="footer">
    <p>AeroSeguro, todos los derechos reservados.</p> 
</footer>