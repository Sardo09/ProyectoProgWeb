<?php
include("base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include("base/funciones.php"); // Incluye el archivo de funciones

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $nombre = $_POST['nombre'];
    $telefono = $_POST['tel'];
    $correo = $_POST['correo'];
    $pass = $_POST['contra'];
    // se verifica si los datos son validos
    // Esta feo y es peor que lo anterior, pero es para que se adapte a JavaScript 
    if($nombre != "" && $telefono != "" && $correo != "" && $pass != ""
    && strlen($nombre) <= 100 && strlen($telefono) <= 16
    && strlen($correo) > 10 && strlen($correo) <= 100 && strlen($pass)<100){
        // Verifica si el correo existe
        $query = "SELECT * FROM usuario WHERE correo='$correo' LIMIT 1";
        $result = mysqli_query($con, $query);
        if($result && mysqli_num_rows($result) > 0){
            echo "<script>alert('El correo ya está registrado');</script>";
        }else{
            // Se agrega el nuevo usuario a la base de datos
            $query = "INSERT INTO usuario (nombre, telefono, correo, contraseña, tipoUsuario) VALUES ('$nombre', '$telefono', '$correo', '$pass', 0)";
            $result = mysqli_query($con, $query);
            echo "<script>alert('Se ha registrado exitosamente');</script>";
            header("Location: login.php"); // Redirige a la página de inicio de sesión
        }

    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <?php include ('base/links.php'); ?>
</head>
<body>
    <header>
        <?php include 'base/header.php'; ?>
    </header>    
    <?php include 'base/barra.php'; ?>
    <br>
    <h2> Crea tu cuenta </h2>
    <section class="formCorreo">
    <form method="POST" class="formCorreo formulario" name="form1">
        <fieldset>
            <div class="div-registro">
                <div class="camposRegistro">
                    <label>Nombre</label>
                    <input class="input-text" type="text" placeholder="Tu Nombre" id="nombre" name="nombre" for="nombre">
                </div>

                <div class="camposRegistro">
                    <label>Teléfono</label>
                    <input class="input-text" type="text" placeholder="Tu Teléfono" id="tel" name="tel" for="tel">
                </div>

                <div class="camposRegistro">
                    <label>Correo</label>
                    <input class="input-text" type="email" placeholder="Tu Email" id="correo" name="correo" for="correo">
                </div>
        
                <div class="camposRegistro">
                    <label>Contraseña</label>
                    <input class="input-text" type="password" placeholder="Tu Contraseña" id="contra" name="contra" for="contra">
                </div>
            </div>
            <div class="alinear-derecha flex">
                <input class="boton w-sm-100" type="submit" value="Crear Cuenta">
            </div>
           <div class="alinear-derecha flex">
                <p>¿Tienes cuenta? <a href="login.php">inicia sesión</a></p>
            </div>
       </fieldset>
    </form>
    </section>
    <?php include 'base/footer.php'; ?>
    
<script src="base/scriptcrearcuenta.js"></script>
</body>
</html>