<?php
include ("base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include ("base/funciones.php"); // Incluye el archivo de funciones
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!--Script para el slider-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <script>
  $(document).ready(function(){
    $(".posti").click(function(){
      // Busca el siguiente .panel después del .flip clickeado
      $(this).next(".panel").slideToggle("slow");
    });
  });
</script>
  <style> 
  .panel, .posti {
    padding: 5px;
    text-align: center;
    cursor: pointer;
  }

  .panel {
    padding: 50px;
    display: none;
  }
  </style>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contacto</title>
  <?php include ('base/links.php'); ?>
</head>
<body>
  <header>
    <?php include 'base/header.php'; ?>
  </header>    
  <?php include 'base/barra.php'; ?>
  <br>
<main class="contenedor sombra">
<div class="posti">
    <h2>Quienes somos</h2>
</div>
  <div class="panel">
    <p style="padding: 5%;">
      Aeroseguro es una empresa dedicada a la venta de boletos de avión, 
      comprometida con ofrecer a sus clientes una experiencia de viaje excepcional. 
      Con un enfoque en la innovación y la atención al cliente, buscamos facilitar 
      el acceso a vuelos seguros y cómodos a destinos alrededor del mundo.
</p>
</div>
<br>
<div class="posti">
  <h2>Mision</h2>
</div>
<div class="panel">
  <p style="padding: 5%;">
    Nuestra misión es proporcionar a nuestros clientes acceso fácil y rápido a
    una amplia gama de opciones de vuelos, asegurando una experiencia de compra 
    segura, confiable y amigable. Buscamos transformar la manera en que las personas 
    planifican y disfrutan de sus viajes, ofreciendo una plataforma intuitiva que se
      adapte a las necesidades de cada viajero.
  </p>
</div>
<br>
<div class="posti">
  <h2>Visión</h2>
</div>
<div class="panel">
  <p style="padding: 5%;">
    Ser la plataforma líder en venta de boletos de avión, reconocida por la innovación, 
    el compromiso con la calidad y el servicio excepcional al cliente. Queremos ser la 
    primera opción para quienes buscan eficiencia, confianza y la mejor relación 
    calidad-precio en sus viajes aéreos.
  </p>
</div>
<br>
<h2>Valores</h2>
<div class="posti">
  
  <ol class="lista">
    <li>
      Compromiso con el cliente: Ponemos a nuestros clientes en el centro de todo lo 
      que hacemos, asegurándonos de ofrecerles una experiencia que supere sus expectativas.
    </li>

    <li>
      Transparencia: Garantizamos procesos claros, sin sorpresas ni cargos ocultos, para 
      que nuestros clientes siempre sepan lo que están pagando.
    </li>
    
    <li>
      Innovación: Estamos en constante evolución para ofrecer soluciones tecnológicas que 
      faciliten la compra de boletos y mejoren la experiencia de viaje.
    </li>

    <li>
      Responsabilidad: Actuamos con integridad y ética, tanto en nuestros servicios como en 
      nuestras relaciones con clientes, proveedores y empleados.
    </li>

    <li>
      Accesibilidad: Trabajamos para que los vuelos sean accesibles para todos, brindando 
      opciones para diferentes presupuestos y necesidades.
    </li>
    </ol>
  </div>
</div> <!--end flex posts -->
</main>
      
    <hr class="separador">
    
    <?php include 'base/footer.php'; ?>
</body>
</html>