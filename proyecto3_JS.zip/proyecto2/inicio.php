<?php
include ("base/conexion.php"); // Incluye el archivo de conexión a la base de datos
include ("base/funciones.php"); // Incluye el archivo de funciones
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <?php include ('base/links.php'); ?>
</head>
<body>
    <header>
        <?php include 'base/header.php'; ?>
    </header>    
        <?php include 'base/barra.php'; ?>
    <br>
    <!-- <section class="banner">
        <div class="contenido-banner">
            <img src="imagenes/banner.jpg" style="width:100%">
            <h2 class="titulo">Seguridad en cada vuelo, tranquilidad en cada destino</h2> 
        </div> contenido-banner
    </section> -->
    
     <div class="container banner">
         <br>
         <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- los botones del carousel -->
            <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- el contenido del carousel -->
            <!-- las imagenes deben de ser de 600 x 265 -->
            <div class="carousel-inner" role="listbox">
                <div class="item active contenido-banner">
                    <img src="imagenes/banner.jpg">
                    <div class="carousel-caption">
                    <h2 class="titulo">Seguridad en cada vuelo, tranquilidad en cada destino</h2>
                    </div>
                </div>
                
                <div class="item contenido-banner">
                    <img src="imagenes/banner2.webp" style="width:600px; height: 350px;">
                    <div class="carousel-caption">
                    <h2 class="titulo">¡No te olvides de revisar nuestras ofertas!</h2>
                    </div>
                </div>
                
                <div class="item contenido-banner">
                    <img src="imagenes/banner3.avif" style="width:600px; height: 350px;">
                    <div class="carousel-caption">
                    <h2 class="titulo">¡Cualquier duda, contactanos!</h2>
                    </div>
                </div>
            </div>

            <!-- Flechas de direccion -->
            <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
            </a>
        </div>
    </div>


    <br><br>
    <main class="contenedor sombra">
        <h1 style="text-align: center;">¿Por qué usar AeroSeguro?</h1>
        <h2></h2>
        <div class="flex-posts">
           <div class="post">
               <h2>Seguridad garantizada</h2>
               <p>Nos aseguramos de que tu vuelo sea seguro en todos los aspectos, con opciones de protección adicional para que viajes tranquilo</p>
           </div>
           <div class="post">
               <h2>Proceso de compra sencillo</h2>
               <p>Nuestro sistema de reservas es fácil y rápido, permitiéndote comprar boletos en minutos desde cualquier dispositivo</p>
           </div>
           <div class="post">
               <h2>Garantía de reembolso</h2>
               <p>En caso de cambios inesperados, garantizamos tu reembolso o reprogramación sin complicaciones</p>
           </div>
           <div class="post">
               <h2>Atención al cliente</h2>
               <p>Un equipo preparado para asesorarte y ayudarte con todos los detalles de tu viaje, desde la compra hasta tu llegada al destino</p>
           </div>
       </div> <!-- .flex-posts -->  
    </main>
    <hr class="separador">
    <!--Los boletos-->
    <h2 style="color:white; font-size: 4rem;">¡Descubre nuestras promociones!</h2>
    <div class="flex-posts">
        <!-- Aquí se muestran los primeros 4 resultados mas recientes-->
        <?php
            $query = "SELECT * FROM aviones ORDER BY idAvion DESC LIMIT 4";
            $result = mysqli_query($con, $query);
            if($result && mysqli_num_rows($result) > 0){
                while ($row = mysqli_fetch_assoc($result)) {
                    $lugarViaje = $row['lugarViaje'];
                    $descLugar = $row['descLugar'];
                    $precio = $row['precio'];
                    $numAsientos = $row['numAsientos'];
                    $imagen = $row['imagen'];
                    echo '<div class="post">';
                    echo '<h2>Vuelos a '.$lugarViaje.'</h2>';
                    echo '<hr>';
                    if ($imagen != "") {
                        echo '<img src="imagenes/'.$imagen.'" class="img-promo">';
                        echo '<hr>';
                    }
                    echo '<p style="text-align: left; margin-bottom: 0; font-size: 0.8rem;">Precio ida y vuelta desde</p>';
                    echo '<p style="text-align: left; margin-top: 0;">MXN<span>$'.$precio.'</span></p>';
                    echo '<a class="boton-promo" type="submit" href="src/pagCompra.php?id='.$row['idAvion'].'">Reservar Ahora</a>';
                    echo '</div>';

                }
            }
        ?>
    </div> <!-- .flex-posts -->
    <?php include 'base/footer.php'; ?>
</body>

</html>